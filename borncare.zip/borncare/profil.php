﻿<?php
include('panel.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<title>
			Your Home Page
		</title>
	</head>
	<body>
		<div id="profil">
			<b id="welcome"> Welcome: $u_username  </b>
		</div>
	</body>
</html>